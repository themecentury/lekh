<?php

/*
 * Core Function goes here
 */
require_once lekh_file_directory('inc/functions/functions.php');

/*
 * Template Tags goes here
 */
require_once lekh_file_directory('inc/functions/template-tags.php');

/*
 * Template Tags goes here
 */
require_once lekh_file_directory('inc/functions/sanitize-customizer.php');