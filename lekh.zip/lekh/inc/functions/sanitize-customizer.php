<?php
/**
 * Define function about sanitation for customizer option
 *
 * @package ThemeCentury
 * @subpackage Lekh
 * @since 1.0.0
 */
//Text

function lekh_links_sanitize() {
	return false;
}
